module.exports = {
    SECRET: 'iewfhu8gyubvctdsbahjknldoewiu8y8y8y8y8y8x8',
}